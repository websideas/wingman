<?php
/**
 * The template for displaying the footer blank
 *
 *
 */
?>
</div><!-- #content -->

<?php if(kt_option('backtotop', true)){ ?>
    <a id="backtotop" href="#page_outter"></a>
<?php } ?>

<?php wp_footer(); ?>

</body>
</html>
