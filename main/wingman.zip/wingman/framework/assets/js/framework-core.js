/*
*
*	Admin $ Functions
*	------------------------------------------------
*
*/



(function($){
    $('document').ready(function() {
        $('body').kt_showhide();
    });
})(jQuery);